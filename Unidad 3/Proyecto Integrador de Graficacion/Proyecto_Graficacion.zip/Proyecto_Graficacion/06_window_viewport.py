import matplotlib.pyplot as plt

def window_to_viewport(xw, yw, xmin, ymin, xmax, ymax, ancho, alto):
    """Mapea coordenadas mundo a pixeles del viewport, con origen abajo-izquierda."""
    sx = ancho / (xmax - xmin)
    sy = alto / (ymax - ymin)
    xv = (xw - xmin) * sx
    yv = (yw - ymin) * sy
    return xv, yv

if __name__ == "__main__":
    # Ventana mundo [-50,50] en X y Y; viewport de 800x600.
    xmin, ymin, xmax, ymax = -50, -50, 50, 50
    ancho, alto = 800, 600
    puntos = {"P1": (10, 10), "P2": (25, 40)}

    sx = ancho / (xmax - xmin)
    sy = alto / (ymax - ymin)
    print(f"Escala horizontal Sx = {sx}")
    print(f"Escala vertical   Sy = {sy}")
    resultados = {}
    for nombre, (x, y) in puntos.items():
        xv, yv = window_to_viewport(x, y, xmin, ymin, xmax, ymax, ancho, alto)
        resultados[nombre] = (xv, yv)
        print(f"{nombre} mundo ({x}, {y}) -> viewport ({xv:.2f}, {yv:.2f})")

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.set_xlim(0, ancho); ax.set_ylim(0, alto)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xticks(range(0, ancho + 1, 100))
    ax.set_yticks(range(0, alto + 1, 100))
    ax.grid(True, linestyle=":")
    for nombre, (xv, yv) in resultados.items():
        ax.scatter(xv, yv, s=60)
        ax.annotate(f"{nombre} ({xv:.0f}, {yv:.0f})", (xv, yv),
                    xytext=(8, 8), textcoords="offset points")
    ax.set_title("Transformacion Window-to-Viewport")
    ax.set_xlabel("X de dispositivo (pixeles)")
    ax.set_ylabel("Y de dispositivo (pixeles)")
    plt.tight_layout()
    plt.show()
